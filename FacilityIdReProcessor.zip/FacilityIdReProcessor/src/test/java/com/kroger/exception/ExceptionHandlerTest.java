package com.kroger.exception;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.dao.BadDataDao;
import com.kroger.dao.BadFacilityDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.LocalPrices;

/**
 * The Class ExceptionHandlerTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ExceptionHandlerTest {
	
	/** The bad data dao. */
	@Mock
	private BadDataDao badDataDao;
	
	/** The bad facility dao. */
	@Mock
	private BadFacilityDao badFacilityDao;

	/** The exception. */
	@Mock
	private Exception exception;
	
	/** The exception handler. */
	@InjectMocks
	private ExceptionHandler exceptionHandler;


	/** The facility not found exception. */
	private FacilityNotFoundException facilityNotFoundException;

	/** The local price. */
	private LocalPrices localPrice;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		facilityNotFoundException = new FacilityNotFoundException("");
		localPrice = new LocalPrices();

	}

	/**
	 * Test handle exception.
	 */
	@Test
	public void testHandleException() {
	//	doReturn(facilityNotFoundException.getClass()).when(exception).getClass();
		doNothing().when(badDataDao).insertBadData(Mockito.<BadData>any());
		doNothing().when(badFacilityDao).insertBadFacility(Mockito.<BadFacility>any());
		exceptionHandler.handleException(facilityNotFoundException, localPrice);
		verify(badDataDao, times(1)).insertBadData(Mockito.<BadData>any());
		verify(badFacilityDao, times(1)).insertBadFacility(Mockito.<BadFacility>any());
	}

}
