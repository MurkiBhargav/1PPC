package com.kroger.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.domain.LocalFinalPrices;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.service.ItemService;
import com.kroger.service.REMService;

/**
 * The Class ItemControllerTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ItemControllerTest {

	/** The local prices. */
	LocalPrices localPrices = new LocalPrices();

	/** The rem entity. */
	RemEntity remEntity = new RemEntity();

	/** The local final prices. */
	LocalFinalPrices localFinalPrices = new LocalFinalPrices();

	/** The item service. */
	@Mock
	ItemService itemServiceMock;
	
	/** The rem service mock. */
	@Mock
	REMService remServiceMock;

	/** The item controller. */
	@InjectMocks
	ItemController itemController;

	/**
	 * Sets up.
	 */
	@Before
	public void setUp() {
		BigDecimal price = new BigDecimal("55");
		localPrices.setDivisionId(10101);
		localPrices.setItemId(00001);
		localPrices.setRegularPrice(price);
		localPrices.setStoreId(12345);
		remEntity.setDivisionId(101010);
		remEntity.setFacilityId(12345567);
		remEntity.setStoreId(3476);
	}

	/**
	 * Test insert local prices.
	 */
	@Test
	public void testInsertLocalPrices() {
		doNothing().when(itemServiceMock).processLocalPrices(Mockito.any(LocalPrices.class));
		itemController.insertLocalPrices(localPrices);
		verify(itemServiceMock).processLocalPrices(Mockito.any(LocalPrices.class));
	}

	/**
	 * Test insert rem entity.
	 */
	@Test
	public void testInsertRemEntity() {
		doNothing().when(remServiceMock).processRemData(Mockito.any(RemEntity.class));
		itemController.insertRemEntity(remEntity);
		verify(remServiceMock).processRemData(Mockito.any(RemEntity.class));
	}

}
