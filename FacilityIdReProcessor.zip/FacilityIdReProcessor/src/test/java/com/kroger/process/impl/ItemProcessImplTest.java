package com.kroger.process.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.dao.LocalFinalPricesDao;
import com.kroger.dao.REMDao;
import com.kroger.domain.LocalFinalPrices;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.service.process.impl.ItemProcessImpl;

/**
 * The Class ItemProcessImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ItemProcessImplTest {
	
	/** The local final prices dao. */
	@Mock
	private LocalFinalPricesDao localFinalPricesDao;
	
	/** The rem dao. */
	@Mock
	private REMDao remDao;
	
	/** The item process impl. */
	@InjectMocks
	private ItemProcessImpl itemProcessImpl;
	
	/** The rem entity. */
	private RemEntity remEntity;
	
	/** The local price. */
	private LocalPrices localPrice;
	

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		remEntity = new RemEntity();
		localPrice= new LocalPrices();
	}

	/**
	 * Test process local prices.
	 */
	@Test
	public void testProcessLocalPrices() {
		doNothing().when(localFinalPricesDao).insertLocalFinalPrices(Mockito.<LocalFinalPrices>any());
		doReturn(remEntity).when(remDao).getFacilityByStoreAndDivision(Mockito.<LocalPrices>any());
		itemProcessImpl.processLocalPrices(localPrice);
		verify(localFinalPricesDao,times(1)).insertLocalFinalPrices(Mockito.<LocalFinalPrices>any());
		verify(remDao,times(1)).getFacilityByStoreAndDivision(Mockito.<LocalPrices>any());
		
		
	}

}
