package com.kroger.service.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.domain.LocalPrices;
import com.kroger.exception.ExceptionHandler;
import com.kroger.exception.FacilityNotFoundException;
import com.kroger.service.process.ItemProcess;

/**
 * The Class ItemServiceImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ItemServiceImplTest {

	/** The bad data dao. */
	@Mock
	private ItemProcess itemProcess;

	/** The bad facility dao. */
	@Mock
	private ExceptionHandler exceptionHandler;

	/** The item service impl. */
	@InjectMocks
	private ItemServiceImpl itemServiceImpl;

	/** The local price. */
	private LocalPrices localPrice;

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		localPrice = new LocalPrices();
	}

	/**
	 * Test process local prices.
	 */
	@Test
	public void testProcessLocalPrices() {
		doNothing().when(itemProcess).processLocalPrices(Mockito.<LocalPrices>any());
		itemServiceImpl.processLocalPrices(localPrice);
		verify(itemProcess, times(1)).processLocalPrices(Mockito.<LocalPrices>any());
		verify(exceptionHandler, times(0)).handleException(Mockito.any(Exception.class), Mockito.<LocalPrices>any());
	}

	/**
	 * Test process local prices when exception.
	 */
	@Test()
	public void testProcessLocalPricesWhenException() {
		doThrow(new FacilityNotFoundException("facility not available")).when(itemProcess)
				.processLocalPrices(Mockito.<LocalPrices>any());
		itemServiceImpl.processLocalPrices(localPrice);
		verify(exceptionHandler, times(1)).handleException(Mockito.any(Exception.class), Mockito.<LocalPrices>any());

	}

}
