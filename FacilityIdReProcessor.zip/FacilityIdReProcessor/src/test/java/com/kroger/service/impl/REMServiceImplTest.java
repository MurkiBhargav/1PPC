package com.kroger.service.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.dao.REMDao;
import com.kroger.domain.RemEntity;
import com.kroger.scheduler.SchedulerService;

/**
 * The Class REMServiceImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class REMServiceImplTest {

	/** The rem dao. */
	@Mock
	private REMDao remDao;

	/** The scheduler service. */
	@Mock
	private SchedulerService schedulerService;

	/** The rem service impl. */
	@InjectMocks
	private REMServiceImpl remServiceImpl;

	/** The rem entity. */
	private RemEntity remEntity;

	/** The rem exception object. */
	private RemEntity remExceptionObject;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		remEntity = new RemEntity();
		remExceptionObject = new RemEntity(100, 1, 1);
	}

	/**
	 * Test process rem data.
	 */
	@Test
	public void testProcessRemData() {
		doNothing().when(remDao).insertRemEntity(Mockito.<RemEntity>any());
		doNothing().when(schedulerService).startRetry();
		remServiceImpl.processRemData(remEntity);
		verify(remDao, times(1)).insertRemEntity(Mockito.<RemEntity>any());
		verify(schedulerService, times(1)).startRetry();
	}

	/**
	 * Test process rem data when exception.
	 */
	@Test
	public void testProcessRemDataWhenException() {
		doNothing().when(remDao).insertRemEntity(Mockito.<RemEntity>any());
		remServiceImpl.processRemData(remExceptionObject);
		verify(remDao, times(1)).insertRemEntity(Mockito.<RemEntity>any());
		verify(schedulerService, times(0)).startRetry();

	}

}
