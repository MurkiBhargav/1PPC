package com.kroger.service.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.domain.BadData;
import com.kroger.domain.LocalPrices;
import com.kroger.service.ItemService;

/**
 * The Class BadDataServiceImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class BadDataServiceImplTest {
	
	/** The item service. */
	@Mock
	private ItemService itemService;
	
	/** The bad data service impl. */
	@InjectMocks
	private BadDataServiceImpl badDataServiceImpl;

	/** The bad data. */
	private BadData badData;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		badData = new BadData();
	}

	/**
	 * Test.
	 */
	@Test
	public void test() {
		doNothing().when(itemService).processLocalPrices(Mockito.<LocalPrices>any());
		badDataServiceImpl.reProcessBadData(badData);
		verify(itemService, times(1)).processLocalPrices(Mockito.<LocalPrices>any());
	}

}
