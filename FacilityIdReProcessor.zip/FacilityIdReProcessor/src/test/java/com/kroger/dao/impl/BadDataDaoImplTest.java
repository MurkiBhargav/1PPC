package com.kroger.dao.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.BadDataDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;

/**
 * The Class BadDataDaoImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
public class BadDataDaoImplTest {

	/** The mapper mock. */
	@Mock
	private Mapper<BadData> mapperMock;

	/** The result set. */
	@Mock
	private ResultSet resultSet;

	/** The mapping manager mock. */
	@Mock
	private MappingManager mappingManagerMock;

	/** The bad data dao. */
	private BadDataDao badDataDao;

	/** The bad data. */
	BadData badData = new BadData();

	/** The price. */
	BigDecimal price = new BigDecimal("35");

	/** The bad datas. */
	List<BadData> badDatas = new ArrayList<BadData>();

	/** The bad facility. */
	BadFacility badFacility = new BadFacility();

	/** The table. */
	String TABLE = "bad_record";

	/**
	 * Setup.
	 */
	@Before
	public void setup() {
		badData.setCause("Facility Id not found");
		badData.setDivisionId(12345);
		badData.setItemId(5435);
		badData.setRegularPrice(price);
		badData.setStoreId(34567);
		badFacility.setDivisionId(2313123);
		badFacility.setItemId(977);
		badFacility.setStoreId(6567);
		badDatas.add(new BadData());
		badDatas.add(new BadData());
		doReturn(mapperMock).when(mappingManagerMock).mapper(BadData.class);
		badDataDao = new BadDataDaoImpl(mappingManagerMock);

	}

	/**
	 * Test insert bad data.
	 */
	@Test
	public void testInsertBadData() {
		doNothing().when(mapperMock).save(Mockito.any(BadData.class));
		badDataDao.insertBadData(badData);
		verify(mapperMock, times(1)).save(Mockito.any(BadData.class));
	}

	/**
	 * Test insert bad data list.
	 */
	@Test
	public void testInsertBadDataList() {
		doNothing().when(mapperMock).save(Mockito.any(BadData.class));
		badDataDao.insertBadData(badDatas);
		verify(mapperMock, times(badDatas.size())).save(Mockito.<BadData>any());
	}

	/**
	 * Test get bad data.
	 */
	@Test
	public void testGetBadData() {
		doReturn(badData).when(mapperMock).get(badFacility.getDivisionId(), badFacility.getStoreId(),
				badFacility.getItemId());
		badDataDao.getBadData(badFacility);
		verify(mapperMock, times(1)).get(badFacility.getDivisionId(), badFacility.getStoreId(),
				badFacility.getItemId());
	}

	/**
	 * Test delete bad data.
	 */
	@Test
	public void testDeleteBadData() {
		doNothing().when(mapperMock).delete(Mockito.<BadData>any());
		badDataDao.deleteBadData(badData);
		verify(mapperMock, times(1)).delete(Mockito.<BadData>any());
	}
}
