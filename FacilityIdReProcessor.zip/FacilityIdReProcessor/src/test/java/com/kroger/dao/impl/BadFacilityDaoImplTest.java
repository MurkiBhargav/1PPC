package com.kroger.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.Statement;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.datastax.driver.mapping.Result;
import com.kroger.domain.BadFacility;

/**
 * The Class BadFacilityDaoImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class BadFacilityDaoImplTest {

	/** The bad facility. */
	BadFacility badFacility = new BadFacility();

	/** The table. */
	String TABLE = "bad_facility";

	/** The mapper mock. */
	@Mock
	private Mapper<BadFacility> mapperMock;

	/** The session mock. */
	@Mock
	private Session sessionMock;

	/** The mapping manager mock. */
	@Mock
	private MappingManager mappingManagerMock;

	/** The result set. */
	@Mock
	private ResultSet resultSet;

	/** The result. */
	@Mock
	private Result<BadFacility> result;

	/** The bad facility dao impl. */
	private BadFacilityDaoImpl badFacilityDaoImpl;

	/** The bad facilities. */
	private List<BadFacility> badFacilities;

	/**
	 * Setup.
	 */
	@Before
	public void setup() {
		doReturn(mapperMock).when(mappingManagerMock).mapper(BadFacility.class);
		doReturn(sessionMock).when(mappingManagerMock).getSession();
		badFacilityDaoImpl = new BadFacilityDaoImpl(mappingManagerMock);
		badFacility.setDivisionId(2313123);
		badFacility.setItemId(977);
		badFacility.setStoreId(6567);
		badFacilities = new ArrayList<BadFacility>();
	}

	/**
	 * Test insert bad facility.
	 */
	@Test
	public void testInsertBadFacility() {
		doNothing().when(mapperMock).save(Mockito.any(BadFacility.class));
		badFacilityDaoImpl.insertBadFacility(badFacility);
		assertNotNull(mapperMock);
		verify(mapperMock).save(Mockito.any(BadFacility.class));
	}

	/**
	 * Test delete bad facility.
	 */
	@Test
	public void testDeleteBadFacility() {
		doNothing().when(mapperMock).delete(Mockito.<BadFacility>any());
		badFacilityDaoImpl.deleteBadFacility(badFacility);
		verify(mapperMock, times(1)).delete(Mockito.<BadFacility>any());
	}

	/**
	 * Test get all retry store division.
	 */
	@Test
	public void testGetAllRetryStoreDivision() {
		doReturn(result).when(mapperMock).map(Mockito.<ResultSet>any());
		doReturn(badFacilities).when(result).all();
		doReturn(resultSet).when(sessionMock).execute(Mockito.<Statement>any());
		badFacilityDaoImpl.getAllRetryStoreDivision();
		verify(sessionMock, times(1)).execute(Mockito.<Statement>any());

	}

}
