package com.kroger.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.LocalFinalPricesDao;
import com.kroger.domain.LocalFinalPrices;

/**
 * The Class LocalFinalPricesDaoImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class LocalFinalPricesDaoImplTest {

	/** The mapper mock. */
	@Mock
	private Mapper<LocalFinalPrices> mapperMock;

	/** The mapping manager mock. */
	@Mock
	private MappingManager mappingManagerMock;

	/** The local final prices dao. */
	private LocalFinalPricesDao localFinalPricesDao;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		doReturn(mapperMock).when(mappingManagerMock).mapper(LocalFinalPrices.class);
		localFinalPricesDao = new LocalFinalPricesDaoImpl(mappingManagerMock);
	}

	/**
	 * Test insert local final prices.
	 */
	@Test
	public void testInsertLocalFinalPrices() {
		doNothing().when(mapperMock).save(Mockito.<LocalFinalPrices>any());
		assertNotNull(mapperMock);
		localFinalPricesDao.insertLocalFinalPrices(Mockito.<LocalFinalPrices>any());
		verify(mapperMock, times(1)).save(Mockito.<LocalFinalPrices>any());
	}

}
