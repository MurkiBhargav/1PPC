package com.kroger.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.exception.FacilityNotFoundException;

/**
 * The Class REMDaoImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class REMDaoImplTest {

	/** The mapper mock. */
	@Mock
	private Mapper<RemEntity> mapperMock;

	/** The mapping manager mock. */
	@Mock
	private MappingManager mappingManagerMock;

	/** The rem dao impl. */
	private REMDaoImpl remDaoImpl;

	/** The rem entity. */
	private RemEntity remEntity;

	/** The bad facility. */
	private BadFacility badFacility;

	/** The bad data. */
	private BadData badData;

	/** The local price. */
	private LocalPrices localPrice;

	/** The rem exception object. */
	private RemEntity remExceptionObject;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		doReturn(mapperMock).when(mappingManagerMock).mapper(RemEntity.class);
		remDaoImpl = new REMDaoImpl(mappingManagerMock);
		remEntity = new RemEntity();
		badFacility = new BadFacility();
		badData = new BadData();
		localPrice = new LocalPrices();
	}

	/**
	 * Test insert rem entity.
	 */
	@Test
	public void testInsertRemEntity() {
		doNothing().when(mapperMock).save(Mockito.<RemEntity>any());
		assertNotNull(mapperMock);
		remDaoImpl.insertRemEntity(remEntity);
		verify(mapperMock, times(1)).save(Mockito.<RemEntity>any());
	}

	/**
	 * Test get facility by store and division when bad facility.
	 */
	@Test
	public void testGetFacilityByStoreAndDivisionWhenBadFacility() {
		doReturn(remEntity).when(mapperMock).get(badFacility.getStoreId(), badFacility.getDivisionId());
		remDaoImpl.getFacilityByStoreAndDivision(badFacility);
		verify(mapperMock, times(1)).get(badFacility.getStoreId(), badFacility.getDivisionId());
		assertNotNull(remEntity);

	}

	/**
	 * Test get facility by store and division when bad data.
	 */
	@Test
	public void testGetFacilityByStoreAndDivisionWhenBadData() {
		doReturn(remEntity).when(mapperMock).get(badData.getStoreId(), badData.getDivisionId());
		remDaoImpl.getFacilityByStoreAndDivision(badData);
		verify(mapperMock, times(1)).get(badData.getStoreId(), badData.getDivisionId());
		assertNotNull(remEntity);

	}

	/**
	 * Test get facility by store and division when local prices.
	 */
	@Test
	public void testGetFacilityByStoreAndDivisionWhenLocalPrices() {
		doReturn(remEntity).when(mapperMock).get(localPrice.getStoreId(), localPrice.getDivisionId());
		remDaoImpl.getFacilityByStoreAndDivision(localPrice);
		verify(mapperMock, times(1)).get(localPrice.getStoreId(), localPrice.getDivisionId());
		assertNotNull(remEntity);
	}

	/**
	 * Test get facility by store and division when local prices with exception.
	 *
	 * @throws FacilityNotFoundException the facility not found exception
	 */
	@Test(expected = FacilityNotFoundException.class)
	public void testGetFacilityByStoreAndDivisionWhenLocalPricesWithException() throws FacilityNotFoundException {
		doReturn(remExceptionObject).when(mapperMock).get(Mockito.<Integer>any(), Mockito.<Integer>any());
		remDaoImpl.getFacilityByStoreAndDivision(localPrice);
	}
}
