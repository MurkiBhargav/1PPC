package com.kroger.scheduler;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.kroger.dao.BadDataDao;
import com.kroger.dao.BadFacilityDao;
import com.kroger.dao.REMDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.RemEntity;
import com.kroger.service.BadDataService;

/**
 * The Class SchedulerServiceTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class SchedulerServiceTest {

	/** The bad data dao. */
	@Mock
	private BadDataDao badDataDao;

	/** The bad facility dao. */
	@Mock
	private BadFacilityDao badFacilityDao;

	/** The rem dao. */
	@Mock
	private REMDao remDao;

	/** The item service. */
	@Mock
	private BadDataService badDataService;

	/** The scheduler service. */
	@InjectMocks
	private SchedulerService schedulerService;

	/** The list. */
	private List<BadFacility> list;

	/** The rem entity. */
	private RemEntity remEntity;

	/** The bad data. */
	private BadData badData;

	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		list = new ArrayList<>();
		list.add(new BadFacility());
		list.add(new BadFacility());
		list.add(new BadFacility());
		remEntity = new RemEntity();
		badData = new BadData();
	}

	/**
	 * Test start retry.
	 */
	@Test
	public void testStartRetry() {
		doReturn(list).when(badFacilityDao).getAllRetryStoreDivision();
		doReturn(remEntity).when(remDao).getFacilityByStoreAndDivision(Mockito.<BadFacility>any());
		doNothing().when(badDataService).reProcessBadData(Mockito.<BadData>any());
		doReturn(badData).when(badDataDao).getBadData(Mockito.<BadFacility>any());
		doNothing().when(badDataDao).deleteBadData(Mockito.<BadData>any());
		doNothing().when(badFacilityDao).deleteBadFacility(Mockito.<BadFacility>any());
		schedulerService.startRetry();
		verify(badFacilityDao, times(1)).getAllRetryStoreDivision();
		verify(remDao, times(3)).getFacilityByStoreAndDivision(Mockito.<BadFacility>any());
		verify(badDataService, times(3)).reProcessBadData(Mockito.<BadData>any());
		verify(badDataDao, times(3)).getBadData(Mockito.<BadFacility>any());
	}
}
