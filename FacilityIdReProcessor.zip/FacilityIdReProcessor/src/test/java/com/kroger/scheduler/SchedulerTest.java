package com.kroger.scheduler;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class SchedulerTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class SchedulerTest {

	/** The scheduler service. */
	@Mock
	private SchedulerService schedulerService;

	/** The scheduler. */
	@InjectMocks
	private Scheduler scheduler;

	/**
	 * Test scheduler.
	 */
	@Test
	public void testScheduler() {
		doNothing().when(schedulerService).startRetry();
		scheduler.schedule();
		verify(schedulerService, times(1)).startRetry();
	}

}
