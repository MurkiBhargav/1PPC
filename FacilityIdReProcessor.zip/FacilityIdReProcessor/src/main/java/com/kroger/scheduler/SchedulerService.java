package com.kroger.scheduler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.dao.BadDataDao;
import com.kroger.dao.BadFacilityDao;
import com.kroger.dao.REMDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.RemEntity;
import com.kroger.service.BadDataService;

/**
 * The Class SchedulerService.
 */
@Service
public class SchedulerService {

	/** The bad data dao. */
	@Autowired
	private BadDataDao badDataDao;

	/** The bad facility dao. */
	@Autowired
	private BadFacilityDao badFacilityDao;

	/** The rem dao. */
	@Autowired
	private REMDao remDao;

	/** The bad data service. */
	@Autowired
	private BadDataService badDataService;
	

	/**
	 * Start retry.
	 */
	public void startRetry() {
		List<BadFacility> badFacilities = badFacilityDao.getAllRetryStoreDivision();
		List<BadFacility> availableFacilities = new ArrayList<>();
		for (BadFacility badFacility : badFacilities) {
			RemEntity remEntity = remDao.getFacilityByStoreAndDivision(badFacility);
			if (remEntity != null) {
				availableFacilities.add(badFacility);
			}
		}
		for (BadFacility availableFacility : availableFacilities) {
			BadData badData = badDataDao.getBadData(availableFacility);
			badDataService.reProcessBadData(badData);
			badDataDao.deleteBadData(badData);
			badFacilityDao.deleteBadFacility(availableFacility);

		}
		badFacilities.clear();
		availableFacilities.clear();

	}
}