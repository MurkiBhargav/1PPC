package com.kroger.domain;
import static com.kroger.utils.CustomConstants.*;

import java.math.BigDecimal;

import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LocalFinalPrices.
 */


/**
 * Instantiates a new local final prices.
 */

@NoArgsConstructor

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@Table(keyspace = KEYSPACE, name = LOCAL_PRICES_TABLE)
@Data
public class LocalFinalPrices {

	/** The facility id. */
	@PartitionKey
	private int facilityId;

	/** The item id. */
	@ClusteringColumn
	private int itemId;

	/** The regular price. */
	@Column
	private BigDecimal regularPrice;

}
