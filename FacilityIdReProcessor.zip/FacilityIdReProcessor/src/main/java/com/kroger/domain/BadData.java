package com.kroger.domain;

import static com.kroger.utils.CustomConstants.BAD_RECORD_TABLE;
import static com.kroger.utils.CustomConstants.KEYSPACE;

import java.math.BigDecimal;

import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BadData.
 */
@Table(keyspace = KEYSPACE, name = BAD_RECORD_TABLE)

/**
 * Instantiates a new bad data.
 */
@NoArgsConstructor

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@Data
public class BadData {

	/** The division id. */
	@PartitionKey(0)
	private int divisionId;

	/** The store id. */
	@PartitionKey(1)
	private int storeId;

	/** The item id. */
	@PartitionKey(2)
	private int itemId;

	/** The regular price. */
	@Column
	private BigDecimal regularPrice;

	/** The cause. */
	@Column
	private String cause;
}
