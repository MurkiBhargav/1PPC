package com.kroger.domain;

import static com.kroger.utils.CustomConstants.*;

import com.datastax.driver.mapping.annotations.ClusteringColumn;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BadFacility.
 */
@Table(keyspace = KEYSPACE, name = BAD_FACILITY_TABLE)

/**
 * Instantiates a new bad facility.
 */
@NoArgsConstructor

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@Data
public class BadFacility {

	/** The store id. */
	@PartitionKey(0)
	private int storeId;

	/** The division id. */
	@PartitionKey(1)
	private int divisionId;

	/** The item id. */
	@ClusteringColumn(0)
	private int itemId;

}
