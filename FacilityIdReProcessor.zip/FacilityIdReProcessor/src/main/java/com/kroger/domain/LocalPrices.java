package com.kroger.domain;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new local prices.
 */
@NoArgsConstructor

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@Data
public class LocalPrices {

	/** The item id. */
	private int itemId;

	/** The store id. */
	private int storeId;

	/** The division id. */
	private int divisionId;

	/** The regular price. */
	private BigDecimal regularPrice;

}