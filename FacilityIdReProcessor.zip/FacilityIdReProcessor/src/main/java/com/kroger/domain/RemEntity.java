package com.kroger.domain;

import static com.kroger.utils.CustomConstants.KEYSPACE;
import static com.kroger.utils.CustomConstants.REM_TABLE;

import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RemEntity.
 */

/**
 * Instantiates a new rem entity.
 */

@NoArgsConstructor

/**
 * Instantiates a new rem entity.
 *
 * @param storeId    the store id
 * @param divisionId the division id
 * @param facilityId the facility id
 */

@AllArgsConstructor

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@Table(keyspace = KEYSPACE, name = REM_TABLE)
@Data
public class RemEntity {

	/** The store id. */
	@PartitionKey(0)
	private int storeId;

	/** The division id. */
	@PartitionKey(1)
	private int divisionId;

	/** The facility id. */
	@Column
	private int facilityId;
}