package com.kroger.utils;

/**
 * The Class CustomConstants.
 */
public class CustomConstants {

	/** The Constant STORE_ID. */
	public static final String STORE_ID = "store_id";

	/** The Constant DIVISION_ID. */
	public static final String DIVISION_ID = "division_id";

	/** The Constant ITEM_ID. */
	public static final String ITEM_ID = "item_id";

	/** The Constant FACILITY_ID. */
	public static final String FACILITY_ID = "facility_id";

	/** The Constant LOCAL_PRICES_TABLE. */
	public static final String LOCAL_PRICES_TABLE = "oneppc_local_prices";

	/** The Constant REM_TABLE. */
	public static final String REM_TABLE = "rem_data";

	/** The Constant BAD_RECORD_TABLE. */
	public static final String BAD_RECORD_TABLE = "bad_record";

	/** The Constant BAD_FACILITY_TABLE. */
	public static final String BAD_FACILITY_TABLE = "bad_facility";

	/** The Constant SPACE. */
	public static final String SPACE = "";

	/** The Constant FACILITY_NOT_AVAILABLE. */
	public static final String FACILITY_NOT_AVAILABLE = "FACILITY ID IS NOT AVAILABLE";

	/** The Constant TRIGGER_FAIL. */
	public static final String TRIGGER_FAIL = "Triggering failed after getting REM data";
	
	/** The Constant KEYSPACE. */
	public static final String KEYSPACE = "oneppc";

}
