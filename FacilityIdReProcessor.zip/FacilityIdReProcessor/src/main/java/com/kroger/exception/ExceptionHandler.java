package com.kroger.exception;
import static com.kroger.utils.CustomConstants.FACILITY_NOT_AVAILABLE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.dao.BadDataDao;
import com.kroger.dao.BadFacilityDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.LocalPrices;

/**
 * The Class ExceptionHandler.
 */
@Service
public class ExceptionHandler {
	
	/** The bad data dao. */
	@Autowired
	private BadDataDao badDataDao;
	
	/** The bad facility dao. */
	@Autowired
	private BadFacilityDao badFacilityDao;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ExceptionHandler.class);

	
	/**
	 * Handle exception.
	 *
	 * @param exception the exception
	 * @param localPrice the local price
	 */
	public void handleException(Exception exception, LocalPrices localPrice) {
		if (exception.getClass() == FacilityNotFoundException.class) {
			BadData badData = new BadData();
			badData.setDivisionId(localPrice.getDivisionId());
			badData.setItemId(localPrice.getItemId());
			badData.setStoreId(localPrice.getStoreId());
			badData.setRegularPrice(localPrice.getRegularPrice());
			badData.setCause(FACILITY_NOT_AVAILABLE);
			badDataDao.insertBadData(badData);
			logger.info("{} got inserted into bad_record", badData);

			BadFacility badFacility = new BadFacility();
			badFacility.setDivisionId(localPrice.getDivisionId());
			badFacility.setItemId(localPrice.getItemId());
			badFacility.setStoreId(localPrice.getStoreId());
			badFacilityDao.insertBadFacility(badFacility);
			logger.info("{} got inserted into bad_facility", badFacility);

		}
	}
}
