package com.kroger.exception;

/**
 * The Class FacilityNotFoundException.
 */
public class FacilityNotFoundException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new facility not found exception.
	 *
	 * @param message the message
	 */
	public FacilityNotFoundException(String message) {
		super(message);
	}

}
