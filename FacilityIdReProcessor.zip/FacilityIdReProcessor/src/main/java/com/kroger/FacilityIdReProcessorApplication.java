package com.kroger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * The Class FacilityIdReProcessorApplication.
 */
@EnableScheduling
@SpringBootApplication
public class FacilityIdReProcessorApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(FacilityIdReProcessorApplication.class, args);
	}

}
