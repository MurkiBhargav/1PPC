package com.kroger.service.impl;

import static com.kroger.utils.CustomConstants.TRIGGER_FAIL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.dao.REMDao;
import com.kroger.domain.RemEntity;
import com.kroger.exception.FacilityNotFoundException;
import com.kroger.scheduler.SchedulerService;
import com.kroger.service.REMService;

/**
 * The Class REMServiceImpl.
 */
@Service
public class REMServiceImpl implements REMService {

	/** The rem dao. */
	@Autowired
	private REMDao remDao;

	/** The scheduler service. */
	@Autowired
	private SchedulerService schedulerService;

	private static final Logger logger = LoggerFactory.getLogger(ItemServiceImpl.class);

	/**
	 * Process rem data.
	 *
	 * @param remEntity the rem entity
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.kroger.service.REMService#processRemData(com.kroger.domain.RemEntity)
	 */
	@Override
	public void processRemData(RemEntity remEntity) {
		remDao.insertRemEntity(remEntity);
		logger.info("{} got inserted into rem_data", remEntity);
		try {
			if (remEntity.getStoreId() == 100)
				throw new FacilityNotFoundException(TRIGGER_FAIL);
			else
				schedulerService.startRetry();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
