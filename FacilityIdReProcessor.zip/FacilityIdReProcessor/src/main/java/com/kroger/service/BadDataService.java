package com.kroger.service;

import com.kroger.domain.BadData;

/**
 * The Interface BadDataService.
 */
public interface BadDataService {
	/**
	 * Re process bad data.
	 *
	 * @param badData the bad data
	 */
	public void reProcessBadData(BadData badData);
}
