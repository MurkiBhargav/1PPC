package com.kroger.service;

import org.springframework.stereotype.Service;

import com.kroger.domain.RemEntity;

/**
 * The Interface REMService.
 */
@Service
public interface REMService {

	/**
	 * Process rem data.
	 *
	 * @param remEntity the rem entity
	 * @return the rem entity
	 */
	public void processRemData(RemEntity remEntity);
}
