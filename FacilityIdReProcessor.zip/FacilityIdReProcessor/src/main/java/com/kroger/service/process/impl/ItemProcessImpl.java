package com.kroger.service.process.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.dao.LocalFinalPricesDao;
import com.kroger.dao.REMDao;
import com.kroger.domain.LocalFinalPrices;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.service.process.ItemProcess;

/**
 * The Class ItemProcessImpl.
 */
@Service
public class ItemProcessImpl implements ItemProcess {
	/** The local final prices dao. */
	@Autowired
	private LocalFinalPricesDao localFinalPricesDao;

	/** The rem dao. */
	@Autowired
	private REMDao remDao;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ItemProcessImpl.class);

	/**
	 * Process local prices.
	 *
	 * @param localPrice the local price
	 */
	@Override
	public void processLocalPrices(LocalPrices localPrice) {
		RemEntity remEntity = remDao.getFacilityByStoreAndDivision(localPrice);

		LocalFinalPrices localFinalPrice = new LocalFinalPrices();
		localFinalPrice.setFacilityId(remEntity.getFacilityId());
		localFinalPrice.setItemId(localPrice.getItemId());
		localFinalPrice.setRegularPrice(localPrice.getRegularPrice());
		localFinalPricesDao.insertLocalFinalPrices(localFinalPrice);
		logger.info("{} got inserted into oneppc_local_price", localFinalPrice);
	}

}
