package com.kroger.service;

import com.kroger.domain.LocalPrices;

/**
 * The Interface ItemService.
 */
public interface ItemService {

	/**
	 * Process local prices.
	 *
	 * @param localPrice the local price
	 */
	public void processLocalPrices(LocalPrices localPrice);

}
