package com.kroger.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.domain.LocalPrices;
import com.kroger.exception.ExceptionHandler;
import com.kroger.exception.FacilityNotFoundException;
import com.kroger.service.ItemService;
import com.kroger.service.process.ItemProcess;

/**
 * The Class ItemServiceImpl.
 */
@Service
public class ItemServiceImpl implements ItemService {

	/** The item process. */
	@Autowired 
	private ItemProcess itemProcess;

	/** The exception handler. */
	@Autowired
	private ExceptionHandler exceptionHandler;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ItemServiceImpl.class);

	/**
	 * Process local prices.
	 *
	 * @param localPrice the local price
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.kroger.service.ItemService#processLocalPrices(com.kroger.domain.
	 * LocalPrices)
	 */
	@Override
	public void processLocalPrices(LocalPrices localPrice) {
		try {
			itemProcess.processLocalPrices(localPrice);
		} catch (FacilityNotFoundException facilityNotFoundException) {
			logger.error("Exception -- {}",facilityNotFoundException.getMessage());
			exceptionHandler.handleException(facilityNotFoundException, localPrice);
		}
	}
}
