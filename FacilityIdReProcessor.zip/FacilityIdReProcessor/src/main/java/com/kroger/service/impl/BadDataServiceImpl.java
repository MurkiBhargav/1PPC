package com.kroger.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kroger.domain.BadData;
import com.kroger.domain.LocalPrices;
import com.kroger.service.BadDataService;
import com.kroger.service.ItemService;

/**
 * The Class BadDataServiceImpl.
 */
@Service
public class BadDataServiceImpl implements BadDataService {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(BadDataServiceImpl.class);
	
	/** The item service. */
	@Autowired
	private ItemService itemService;

	/**
	 * Re process bad data.
	 *
	 * @param badData the bad data
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.kroger.service.ItemService#reProcessBadData(com.kroger.domain.BadData)
	 */
	@Override
	public void reProcessBadData(BadData badData) {
		LocalPrices localPrice = new LocalPrices();
		localPrice.setItemId(badData.getItemId());
		localPrice.setDivisionId(badData.getDivisionId());
		localPrice.setStoreId(badData.getStoreId());
		localPrice.setRegularPrice(badData.getRegularPrice());
		logger.info("Reprocessing of {} started", badData);
		itemService.processLocalPrices(localPrice);
		logger.info("Reprocessed completed");
	}

}
