package com.kroger.service.process;

import org.springframework.stereotype.Service;

import com.kroger.domain.LocalPrices;

/**
 * The Interface ItemProcess.
 */
@Service
public interface ItemProcess {
	
	/**
	 * Process local prices.
	 *
	 * @param localPrice the local price
	 */
	public void processLocalPrices(LocalPrices localPrice);
	
}
