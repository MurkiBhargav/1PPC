package com.kroger.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.service.ItemService;
import com.kroger.service.REMService;

/**
 * The Class ItemController.
 */
@RestController
public class ItemController {

	/** The item service. */
	@Autowired
	private ItemService itemService;

	/** The rem service. */
	@Autowired
	private REMService remService;

	/**
	 * Insert local prices.
	 *
	 * @param localPrice the local price
	 * @return the local prices
	 */
	@PostMapping(value = "/localPrices")
	public String insertLocalPrices(@RequestBody LocalPrices localPrice) {
		itemService.processLocalPrices(localPrice);
		return "LocalPrices processed";
	}

	/**
	 * Insert rem entity.
	 *
	 * @param remEntity the rem entity
	 * @return the rem entity
	 */
	@PostMapping(value = "/rem")
	public String insertRemEntity(@RequestBody RemEntity remEntity) {
		remService.processRemData(remEntity);
		return "Rem Data Inserted";
	}

}
