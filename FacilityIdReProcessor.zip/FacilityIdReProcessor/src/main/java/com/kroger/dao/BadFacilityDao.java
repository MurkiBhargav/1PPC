package com.kroger.dao;

import java.util.List;

import com.kroger.domain.BadFacility;

/**
 * The Interface BadFacilityDao.
 */
public interface BadFacilityDao {

	/**
	 * Gets the all retry store division.
	 *
	 * @return the all retry store division
	 */
	public List<BadFacility> getAllRetryStoreDivision();

	/**
	 * Insert bad facility.
	 *
	 * @param badFacility the bad facility
	 */
	public void insertBadFacility(BadFacility badFacility);

	/**
	 * Delete bad facility.
	 *
	 * @param badFacility the bad facility
	 */
	public void deleteBadFacility(BadFacility badFacility);
}
