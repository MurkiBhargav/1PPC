package com.kroger.dao;

import com.kroger.domain.LocalFinalPrices;

/**
 * The Interface LocalFinalPricesDao.
 */
public interface LocalFinalPricesDao {

	/**
	 * Insert local final prices.
	 *
	 * @param localFinalPrices the local final prices
	 */
	public void insertLocalFinalPrices(LocalFinalPrices localFinalPrices);
}
