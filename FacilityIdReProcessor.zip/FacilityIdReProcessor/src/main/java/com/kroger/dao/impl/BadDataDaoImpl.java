package com.kroger.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.BadDataDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;

/**
 * The Class BadDataRepository.
 */
@Repository
public class BadDataDaoImpl implements BadDataDao {

	/** The mapper. */
	private Mapper<BadData> mapper;

	/**
	 * Instantiates a new bad data repository.
	 *
	 * @param mappingManager the mapping manager
	 */
	public BadDataDaoImpl(MappingManager mappingManager) {
		this.mapper = mappingManager.mapper(BadData.class);

	}

	/**
	 * Insert bad data.
	 *
	 * @param badData the bad data
	 */
	public void insertBadData(BadData badData) {
		mapper.save(badData);
	}

	/**
	 * Insert bad data.
	 *
	 * @param badDatas the bad datas
	 */
	public void insertBadData(List<BadData> badDatas) {
		for (BadData badData : badDatas) {
			mapper.save(badData);
		}
	}

	/**
	 * Gets the bad data.
	 *
	 * @param badFacility the bad facility
	 * @return the bad data
	 */
	public BadData getBadData(BadFacility badFacility) {
		return mapper.get(badFacility.getDivisionId(), badFacility.getStoreId(), badFacility.getItemId());
	}

	/**
	 * Delete bad data.
	 *
	 * @param badData the bad data
	 */
	public void deleteBadData(BadData badData) {
		mapper.delete(badData);
	}
}
