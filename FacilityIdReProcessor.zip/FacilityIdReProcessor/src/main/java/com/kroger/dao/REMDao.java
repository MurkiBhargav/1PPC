package com.kroger.dao;

import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;

/**
 * The Interface REMDao.
 */
public interface REMDao {

	/**
	 * Insert rem entity.
	 *
	 * @param remEntity the rem entity
	 */
	public void insertRemEntity(RemEntity remEntity);

	/**
	 * Gets the facility by store and division.
	 *
	 * @param badFacility the bad facility
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(BadFacility badFacility);

	/**
	 * Gets the facility by store and division.
	 *
	 * @param badData the bad data
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(BadData badData);

	/**
	 * Gets the facility by store and division.
	 *
	 * @param localPrice the local price
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(LocalPrices localPrice);
}
