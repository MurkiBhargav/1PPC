package com.kroger.dao.impl;

import static com.datastax.driver.core.querybuilder.QueryBuilder.select;
import static com.kroger.utils.CustomConstants.BAD_FACILITY_TABLE;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.BadFacilityDao;
import com.kroger.domain.BadFacility;

/**
 * The Class BadFacilityRepository.
 */
@Repository
public class BadFacilityDaoImpl implements BadFacilityDao {

	/** The mapper. */
	private Mapper<BadFacility> mapper;

	/** The session. */
	private Session session;

	/**
	 * Instantiates a new bad facility repository.
	 *
	 * @param mappingManager the mapping manager
	 */
	public BadFacilityDaoImpl(MappingManager mappingManager) {
		this.mapper = mappingManager.mapper(BadFacility.class);
		this.session = mappingManager.getSession();
	}

	/**
	 * Gets the all retry store division.
	 *
	 * @return the all retry store division
	 */
	public List<BadFacility> getAllRetryStoreDivision() {
		final ResultSet resultSet = session
				.execute(select().all().from(BAD_FACILITY_TABLE).allowFiltering());
		return mapper.map(resultSet).all();
	}

	/**
	 * Insert bad facility.
	 *
	 * @param badFacility the bad facility
	 * @return the bad facility
	 */
	public void insertBadFacility(BadFacility badFacility) {
		mapper.save(badFacility);
	}

	/**
	 * Delete bad facility.
	 *
	 * @param badFacility the bad facility
	 */
	public void deleteBadFacility(BadFacility badFacility) {
		mapper.delete(badFacility);
	}
}