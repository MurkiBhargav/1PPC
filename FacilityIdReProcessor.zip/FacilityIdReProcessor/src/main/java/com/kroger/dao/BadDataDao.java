package com.kroger.dao;

import java.util.List;

import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;

/**
 * The Interface BadDataDao.
 */
public interface BadDataDao {

	/**
	 * Insert bad data.
	 *
	 * @param badData the bad data
	 */
	public void insertBadData(BadData badData);

	/**
	 * Insert bad data.
	 *
	 * @param badDatas the bad datas
	 */
	public void insertBadData(List<BadData> badDatas);

	/**
	 * Gets the bad data.
	 *
	 * @param badFacility the bad facility
	 * @return the bad data
	 */
	public BadData getBadData(BadFacility badFacility);

	/**
	 * Delete bad data.
	 *
	 * @param badData the bad data
	 */
	public void deleteBadData(BadData badData);

}
