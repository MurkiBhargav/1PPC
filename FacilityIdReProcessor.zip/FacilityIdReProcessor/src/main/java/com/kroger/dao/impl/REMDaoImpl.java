package com.kroger.dao.impl;

import static com.kroger.utils.CustomConstants.*;
import org.springframework.stereotype.Repository;

import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.REMDao;
import com.kroger.domain.BadData;
import com.kroger.domain.BadFacility;
import com.kroger.domain.LocalPrices;
import com.kroger.domain.RemEntity;
import com.kroger.exception.FacilityNotFoundException;

/**
 * The Class RemRepository.
 */
@Repository
public class REMDaoImpl implements REMDao {

	/** The mapper. */
	private Mapper<RemEntity> mapper;

	/**
	 * Instantiates a new rem repository.
	 *
	 * @param mappingManager the mapping manager
	 */
	public REMDaoImpl(MappingManager mappingManager) {
		this.mapper = mappingManager.mapper(RemEntity.class);
	}

	/**
	 * Insert rem entity.
	 *
	 * @param remEntity the rem entity
	 */
	public void insertRemEntity(RemEntity remEntity) {
		mapper.save(remEntity);
	}

	/**
	 * Gets the facility by store and division.
	 *
	 * @param badFacility the bad facility
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(BadFacility badFacility) {
		return mapper.get(badFacility.getStoreId(), badFacility.getDivisionId());
	}

	/**
	 * Gets the facility by store and division.
	 *
	 * @param badData the bad data
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(BadData badData) {
		return mapper.get(badData.getStoreId(), badData.getDivisionId());
	}

	/**
	 * Gets the facility by store and division.
	 *
	 * @param localPrice the local price
	 * @return the facility by store and division
	 */
	public RemEntity getFacilityByStoreAndDivision(LocalPrices localPrice) {
		RemEntity remEntity = mapper.get(localPrice.getStoreId(), localPrice.getDivisionId());
		if (remEntity == null)
			throw new FacilityNotFoundException(FACILITY_NOT_AVAILABLE);
		return remEntity;
	}
}
