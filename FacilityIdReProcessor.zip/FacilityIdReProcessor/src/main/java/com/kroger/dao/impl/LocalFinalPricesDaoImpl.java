package com.kroger.dao.impl;

import org.springframework.stereotype.Repository;

import com.datastax.driver.mapping.Mapper;
import com.datastax.driver.mapping.MappingManager;
import com.kroger.dao.LocalFinalPricesDao;
import com.kroger.domain.LocalFinalPrices;

/**
 * The Class LocalFinalPricesRepository.
 */
@Repository
public class LocalFinalPricesDaoImpl implements LocalFinalPricesDao {

	/** The mapper. */
	private Mapper<LocalFinalPrices> mapper;

	/**
	 * Instantiates a new local final prices repository.
	 *
	 * @param mappingManager the mapping manager
	 */
	public LocalFinalPricesDaoImpl(MappingManager mappingManager) {
		this.mapper = mappingManager.mapper(LocalFinalPrices.class);
	}

	/**
	 * Insert local final prices.
	 *
	 * @param localFinalPrices the local final prices
	 */
	public void insertLocalFinalPrices(LocalFinalPrices localFinalPrices) {
		mapper.save(localFinalPrices);
	}
}
